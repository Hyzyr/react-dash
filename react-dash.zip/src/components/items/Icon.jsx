import React from "react";

const Icon = ({ svg }) => {
  return <span className="icon">{svg}</span>;
};

export default Icon;

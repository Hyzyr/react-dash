import React from "react";

const AutoContainer = (props) => {
  return <div className="autoContainer" {...props} />;
};

export default AutoContainer;
